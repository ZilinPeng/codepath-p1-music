let playlists = [];
let likedSet = new Set();
let currentPlaylist = null;

// Fisher-Yates Shuffle
function shuffleArray(arr) {
  let m = arr.length, i;
  while (m) {
    i = Math.floor(Math.random() * m--);
    [arr[m], arr[i]] = [arr[i], arr[m]];
  }
  return arr;
}

// Function to render all playlist cards
function renderGrid(list) {
  const grid = document.getElementById("playlist-grid");
  grid.innerHTML = ""; 

  list.forEach(pl => {
    const tile = document.createElement("div");
    tile.className = "playlist-tile";
    tile.innerHTML = `
      <img src="${pl.playlist_art}" alt="${pl.playlist_name}">
      <div class="playlist-info">
        <h3>${pl.playlist_name}</h3>
        <p>by ${pl.playlist_author}</p>
        <div class="likes">
          <span class="count">${pl.likes}</span>
          <button class="heart ${likedSet.has(pl.playlistID) ? 'liked' : ''}">♥</button>
        </div>
      </div>
    `;

    // Clicking the tile opens the modal
    tile.querySelector("img, .playlist-info").addEventListener("click", () => {
      openModal(pl);
    });

    // Heart button
    const heartBtn = tile.querySelector(".heart");
    heartBtn.addEventListener("click", e => {
      e.stopPropagation();
      if (likedSet.has(pl.playlistID)) {
        likedSet.delete(pl.playlistID);
        pl.likes--;
        heartBtn.classList.remove("liked");
      } else {
        likedSet.add(pl.playlistID);
        pl.likes++;
        heartBtn.classList.add("liked");
      }
      tile.querySelector(".count").textContent = pl.likes;
    });

    grid.appendChild(tile);
  });
}

// Show playlist details in modal
function openModal(pl) {
  currentPlaylist = pl;
  document.getElementById("modal-cover").src = pl.playlist_art;
  document.getElementById("modal-name").textContent = pl.playlist_name;
  document.getElementById("modal-author").textContent = `by ${pl.playlist_author}`;
  renderSongList(pl.songs);
  document.getElementById("modal-overlay").classList.remove("hidden");
}

function renderSongList(songs) {
  const ul = document.getElementById("modal-songs");
  ul.innerHTML = "";
  songs.forEach(s => {
    const li = document.createElement("li");
    li.textContent = `${s.title} — ${s.artist} (${s.duration})`;
    ul.appendChild(li);
  });
}

// Modal close
document.getElementById("modal-close").addEventListener("click", () => {
  document.getElementById("modal-overlay").classList.add("hidden");
});
document.getElementById("modal-overlay").addEventListener("click", e => {
  if (e.target.id === "modal-overlay") {
    e.target.classList.add("hidden");
  }
});

// Search
document.getElementById("search-btn").addEventListener("click", () => {
  const q = document.getElementById("search-input").value.toLowerCase();
  const filtered = playlists.filter(pl =>
    pl.playlist_name.toLowerCase().includes(q) ||
    pl.playlist_author.toLowerCase().includes(q)
  );
  renderGrid(filtered);
});

document.getElementById("clear-btn").addEventListener("click", () => {
  document.getElementById("search-input").value = "";
  renderGrid(playlists);
});

// Sort
document.getElementById("sort-select").addEventListener("change", e => {
  const val = e.target.value;
  let sorted = [...playlists];
  if (val === "name") {
    sorted.sort((a, b) => a.playlist_name.localeCompare(b.playlist_name));
  } else if (val === "likes") {
    sorted.sort((a, b) => b.likes - a.likes);
  } else if (val === "date") {
    sorted.sort((a, b) => new Date(b.dateAdded) - new Date(a.dateAdded));
  }
  renderGrid(sorted);
});

// Shuffle in modal
document.getElementById("shuffle-btn").addEventListener("click", () => {
  if (!currentPlaylist) return;
  const copy = shuffleArray([...currentPlaylist.songs]);
  renderSongList(copy);
});

// Fetch the JSON and initialize
document.addEventListener("DOMContentLoaded", () => {
  fetch("./data/data.json")
    .then(res => res.json())
    .then(data => {
      playlists = data.playlists;
      renderGrid(playlists);
    })
    .catch(err => console.error("Failed to load playlists:", err));
});